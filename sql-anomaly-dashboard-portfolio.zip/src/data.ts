// src/data.ts

export interface NodeItem {
  id: string;
  parent_id: string;
  name: string;
  role: string;
}

export interface OrderItem {
  no_urut: number;
  node_id: string;
  nilai_order: number;
  notes?: string;
  cause?: string;
}

// Hierarchical organizational nodes (Adjacency List model matched to the SQL design)
export const INITIAL_NODES: NodeItem[] = [
  // Level 1: Root placeholder
  { id: "ROOT", parent_id: "", name: "Global Enterprise", role: "HQ" },
  
  // Level 2: Direct children of 'ROOT' (Level-2 Managers representing Regions)
  { id: "WEST_REG", parent_id: "ROOT", name: "Budi Setiawan", role: "Regional VP West" },
  { id: "EAST_REG", parent_id: "ROOT", name: "Siti Aminah", role: "Regional VP East" },
  { id: "CENT_REG", parent_id: "ROOT", name: "Rian Hidayat", role: "Regional VP Central" },
  
  // Level 3: Area Map (Children of Regional Directors)
  { id: "CA_AREA", parent_id: "WEST_REG", name: "Heri Prasetyo", role: "Area Manager - California" },
  { id: "NY_AREA", parent_id: "EAST_REG", name: "Diana Putri", role: "Area Manager - New York" },
  { id: "IL_AREA", parent_id: "CENT_REG", name: "Andi Wijaya", role: "Area Manager - Illinois" },
  
  // Level 4: Branches (Children of Area Managers)
  { id: "SF_BRANCH", parent_id: "CA_AREA", name: "Bayu Pratama", role: "Branch Head - San Francisco" },
  { id: "LA_BRANCH", parent_id: "CA_AREA", name: "Santi Susanti", role: "Branch Head - Los Angeles" },
  { id: "NYC_BRANCH", parent_id: "NY_AREA", name: "Denny Siregar", role: "Branch Head - NYC Downtown" },
  { id: "CHI_BRANCH", parent_id: "IL_AREA", name: "Fitri Astuti", role: "Branch Head - Chicago Loop" },
  
  // Level 5: Store Fronts or Agents (Children of Branches)
  { id: "SF_STORE_A", parent_id: "SF_BRANCH", name: "Imran Khan", role: "Store Lead SF-A" },
  { id: "LA_STORE_A", parent_id: "LA_BRANCH", name: "Dewi Lestari", role: "Store Lead LA-A" },
  { id: "NY_STORE_A", parent_id: "NYC_BRANCH", name: "Linda Wahyuni", role: "Store Lead NYC-A" },
  { id: "CHI_STORE_A", parent_id: "CHI_BRANCH", name: "Agung Pramono", role: "Store Lead CHI-A" },
];

// Initial orders dataset
export const INITIAL_ORDERS: OrderItem[] = [
  // WEST REGION (Budi Setiawan) – Typical Average around 3,000
  { no_urut: 1, node_id: "SF_STORE_A", nilai_order: 2500, notes: "Regular branch sales" },
  { no_urut: 2, node_id: "SF_STORE_A", nilai_order: 3100, notes: "Regular branch sales" },
  { no_urut: 3, node_id: "LA_STORE_A", nilai_order: 2800, notes: "Regular branch sales" },
  { no_urut: 4, node_id: "SF_STORE_A", nilai_order: 2900, notes: "Regular branch sales" },
  // West Region Anomaly: Z-score > 3
  { no_urut: 5, node_id: "SF_STORE_A", nilai_order: 48000, notes: "Outlier: Fat-finger input error", cause: "Human Input Error" },
  { no_urut: 6, node_id: "LA_STORE_A", nilai_order: 3400, notes: "Regular branch sales" },
  { no_urut: 7, node_id: "SF_STORE_A", nilai_order: 2100, notes: "Regular branch sales" },

  // EAST REGION (Siti Aminah) – Typical Average around 4,500
  { no_urut: 8, node_id: "NY_STORE_A", nilai_order: 4200, notes: "Regular East segment sales" },
  { no_urut: 9, node_id: "NY_STORE_A", nilai_order: 5100, notes: "Regular East segment sales" },
  { no_urut: 10, node_id: "NY_STORE_A", nilai_order: 4500, notes: "Regular East segment sales" },
  // East Region Anomaly: Extremely high, suspected corporate invoice error
  { no_urut: 11, node_id: "NY_STORE_A", nilai_order: 95000, notes: "Outlier: Multiplied wholesale order", cause: "System Glitch / Double Billing" },
  { no_urut: 12, node_id: "NY_STORE_A", nilai_order: 4800, notes: "Regular East segment sales" },
  { no_urut: 13, node_id: "NY_STORE_A", nilai_order: 3900, notes: "Regular East segment sales" },

  // CENTRAL REGION (Rian Hidayat) – Typical Average around 1,800
  { no_urut: 14, node_id: "CHI_STORE_A", nilai_order: 1500, notes: "Regular Central sales" },
  { no_urut: 15, node_id: "CHI_STORE_A", nilai_order: 2000, notes: "Regular Central sales" },
  { no_urut: 16, node_id: "CHI_STORE_A", nilai_order: 1700, notes: "Regular Central sales" },
  { no_urut: 17, node_id: "CHI_STORE_A", nilai_order: 1650, notes: "Regular Central sales" },
  { no_urut: 18, node_id: "CHI_STORE_A", nilai_order: 1900, notes: "Regular Central sales" },
  // Central Region Anomaly: Suspected rogue pricing discount bypass
  { no_urut: 19, node_id: "CHI_STORE_A", nilai_order: 32000, notes: "Outlier: Suspected pricing error bypass", cause: "Unauthorized Staff Override" },
  { no_urut: 20, node_id: "CHI_STORE_A", nilai_order: 1800, notes: "Regular Central sales" },
];

export interface ProcessedQueryResult {
  level2: string | null;
  jumlah_anomali: number | null;
  id: string | null;
  nilai_order: number | null;
  average: number | null;
  stdev: number | null;
  jarak_average: number | null;
  z_score: number | null;
  sort_type: number;
  sort_level2: string;
}

// Simulates the exact SQL multi-step mathematical execution
export function executeSqlSimulation(
  nodes: NodeItem[],
  orders: OrderItem[]
): ProcessedQueryResult[] {
  // Helper to trace up to 6 nodes to find Direct Child of (parent_id = ROOT)
  const findLevel2 = (nodeId: string): string | null => {
    let current = nodes.find(n => n.id === nodeId);
    if (!current) return null;

    // Track up to 6 levels hierarchical hop
    for (let i = 0; i < 6; i++) {
      if (current.parent_id === "ROOT") {
        return current.id;
      }
      const parent = nodes.find(n => n.id === current?.parent_id);
      if (!parent) break;
      current = parent;
    }
    return null;
  };

  // 1. Flatten hierarchy and associate Level-2 Region for each order
  const ordersWithLevel2 = orders.map(o => {
    const level2 = findLevel2(o.node_id);
    return { ...o, level2 };
  }).filter(o => o.level2 !== null) as Array<OrderItem & { level2: string }>;

  // 2. Compute grouping statistics (Average and STDDEV_POP)
  const statsMap: Record<string, { average: number; stdev: number }> = {};
  
  // Group level2 list
  const distinctLevel2s = Array.from(new Set(ordersWithLevel2.map(o => o.level2)));

  distinctLevel2s.forEach(lvl2 => {
    const regionOrders = ordersWithLevel2.filter(o => o.level2 === lvl2);
    const sum = regionOrders.reduce((acc, o) => acc + o.nilai_order, 0);
    const average = sum / regionOrders.length;

    // STDDEV_POP = sqrt(sum((x - mean)^2) / N)
    const variance = regionOrders.reduce((acc, o) => acc + Math.pow(o.nilai_order - average, 2), 0) / regionOrders.length;
    const stdev = Math.sqrt(variance);

    statsMap[lvl2] = { average, stdev };
  });

  // 3. Find anomalies where ABS(Z-Score) > 3
  const anomalies = ordersWithLevel2.map(o => {
    const stats = statsMap[o.level2];
    const avg = stats.average;
    const std = stats.stdev;
    const distance = o.nilai_order - avg;
    const z = std > 0 ? distance / std : 0;
    const isAnomaly = std > 0 && Math.abs(z) > 3;

    return {
      ...o,
      average: avg,
      stdev: std,
      jarak_average: distance,
      z_score: z,
      isAnomaly,
    };
  });

  // Filter only those that qualify as outliers (ABS(Z-Score) > 3)
  const anomaliesOnly = anomalies.filter(a => a.isAnomaly);

  // Group anomalies to generate Section 1: Summary Rows
  // SELECT level2, COUNT(*) as jumlah_anomali, ... GROUP BY base.level2
  const summaries: ProcessedQueryResult[] = distinctLevel2s.map(lvl2 => {
    const regionAnomalies = anomaliesOnly.filter(a => a.level2 === lvl2);
    if (regionAnomalies.length === 0) return null;

    return {
      level2: lvl2,
      jumlah_anomali: regionAnomalies.length,
      id: null,
      nilai_order: null,
      average: null,
      stdev: null,
      jarak_average: null,
      z_score: null,
      sort_type: 1, // Summary Row
      sort_level2: lvl2,
    };
  }).filter(s => s !== null) as ProcessedQueryResult[];

  // Generate Section 2: Detail Rows
  const details: ProcessedQueryResult[] = anomaliesOnly.map(a => {
    return {
      level2: null,
      jumlah_anomali: null,
      id: a.node_id,
      nilai_order: a.nilai_order,
      average: a.average,
      stdev: a.stdev,
      jarak_average: a.jarak_average,
      z_score: a.z_score,
      sort_type: 2, // Detail Row
      sort_level2: a.level2,
    };
  });

  // Combine following the UNION ALL sorting order rules:
  // ORDER BY sort_type ASC, sort_level2 ASC, id ASC
  return [...summaries, ...details].sort((a, b) => {
    if (a.sort_type !== b.sort_type) {
      return a.sort_type - b.sort_type;
    }
    if (a.sort_level2 !== b.sort_level2) {
      return a.sort_level2.localeCompare(b.sort_level2);
    }
    const idA = a.id || "";
    const idB = b.id || "";
    return idA.localeCompare(idB);
  });
}

// Complete Slide Deck Content mapping for the Portfolio Presenter
export interface SlideData {
  id: number;
  title: string;
  subtitle: string;
  points: string[];
  visualType: "stats" | "architecture" | "query" | "rca" | "action" | "title";
  badge: string;
}

export const PRESENTATION_SLIDES: SlideData[] = [
  {
    id: 1,
    title: "SQL Anomaly Detection & Sales Performance Root Cause Analysis",
    subtitle: "End-to-End Enterprise Data Analytics Portfolio Case Study",
    points: [
      "Objective: Identify operational pricing anomalies & data pipeline failures affecting top-line reporting.",
      "Tech Stack: MySQL 8.0, DBeaver IDE, Recharts, standard deviations.",
      "Methodology: Statistical outlier filtering using Z-Score threshold calculation (|Z| > 3.0) on multi-level management structures."
    ],
    visualType: "title",
    badge: "Case Introduction"
  },
  {
    id: 2,
    title: "The Business Problem: Undetected Financial Drift",
    subtitle: "How standard aggregate sales reports masked high-impact operational defects",
    points: [
      "Revenue Variance: Regional sales figures fluctuated drastically month-over-month with no clear correlation.",
      "Data Poisoning: Single miskeyed high-order amount (Fat-Finger error) skewed regional averages, ruining KPI forecasts.",
      "System Weakness: ERP transaction gateways allowed arbitrary pricing overrides without manager approvals.",
      "Financial Exposure: Ghost sales or billing bugs artificially inflated tax liabilities and commercial commissions."
    ],
    visualType: "stats",
    badge: "Business Context"
  },
  {
    id: 3,
    title: "Data Architecture & Hierarchical Flattening",
    subtitle: "Overcoming MySQL performance limitations on deep-level organizational structures",
    points: [
      "Hierarchical Adjacency Model: Nodes represented stores, branches, areas, and regions mapped via parent-child relations.",
      "Dynamic Deep Tracing: Implemented 6-level sequential LEFT JOIN layers to identify the high-level Level-2 Regional Manager.",
      "No-Recursion Performance: Shifting from recursive CTEs to flattened sequential queries reduced query processing from minutes to milliseconds.",
      "Statistical Isolation: Ensured standard deviations were strictly calculated within the context of each separate regional manager's baseline."
    ],
    visualType: "architecture",
    badge: "Pipeline Architecture"
  },
  {
    id: 4,
    title: "MySQL Implementation Breakdown",
    subtitle: "Dissecting standard deviation population metrics and the dual-layer output query",
    points: [
      "Aggregate Base (Subquery stats): GROUP BY level2 calculating standard AVG and STDDEV_POP.",
      "Z-Score Formulation: Calculated dynamically using (nilai_order - average) / stdev per transaction",
      "Dynamic UNION ALL: Segregating Section 1 (Summary anomaly counts per VP) and Section 2 (Detailed outlier transactions).",
      "Unified Sorting Framework: Guaranteed sequential visual order matching: 'ORDER BY sort_type ASC, sort_level2 ASC'."
    ],
    visualType: "query",
    badge: "SQL Technical Code"
  },
  {
    id: 5,
    title: "Critical RCA Insights (Data Anomaly Diagnosis)",
    subtitle: "Translating statistical anomalies (Z-Score > 3) into concrete organizational events",
    points: [
      "Budi Setiawan (West Region Outlier): $48,000 order value traced to manual entry bypass (Fat-Finger error, keyed 48000 instead of 4800).",
      "Siti Aminah (East Region Outlier): $95,000 corporate account wholesale billing double-pass glitch.",
      "Rian Hidayat (Central Region Outlier): $32,000 pricing adjustment that bypassed branch approvals."
    ],
    visualType: "rca",
    badge: "Analytical Discovery"
  },
  {
    id: 6,
    title: "Action Guidelines & Executive Decisions",
    subtitle: "Continuous alert threshold triggers to safeguard data integrity and margins",
    points: [
      "Gateway Input Masks: Deploy rigid decimal checking in ERP to block simple typing mistakes (limits single order multiplier).",
      "Automated Alerting: Configure daily DBeaver scheduled scripts to email VPs automatically when any order breaches Z > 3.0.",
      "Approval Workflows: Require cryptographic overrides from area managers for order overrides totaling more than 10x the branch run-rate.",
      "Audit Trail Integrity: Maintain historical analytics of anomalies to isolate repetitive user behavior and train operators."
    ],
    visualType: "action",
    badge: "Executive Roadmap"
  }
];

export const RAW_SQL_QUERY = `-- Recovering Sales
-- Performance Root Cause
-- Tools: MySQL.8.0-MySQL WORKBENCH.8.0-IDE.Dbeaver
-- 
-- Methode ini menggunakan tehnik perhitungan Statistik Dasar:
-- Average
-- Standart Deviation
-- Standart Deviation Populasi (STDDEV-POP)
-- Z-Score
--

SELECT 
    level2, 
    jumlah_anomali, 
    id, 
    nilai_order, 
    average, 
    stdev, 
    jarak_average, 
    z_score
FROM (
    -- ====================================================================
    -- BAGIAN 1: SUMMARY ROWS 
    -- Menghitung jumlah anomali per Manager Level-2
    -- ====================================================================
    SELECT 
        base.level2 AS level2,
        COUNT(*) AS jumlah_anomali,
        NULL AS id,
        NULL AS nilai_order,
        NULL AS average,
        NULL AS stdev,
        NULL AS jarak_average,
        NULL AS z_score,
        1 AS sort_type,
        base.level2 AS sort_level2
    FROM (
        -- Meratakan hierarki menggunakan LEFT JOIN beruntun
        SELECT 
            o.no_urut,
            o.node_id,
            o.nilai_order,
            COALESCE(
                CASE WHEN n1.parent_id = 'ROOT' THEN n1.id END,
                CASE WHEN n2.parent_id = 'ROOT' THEN n2.id END,
                CASE WHEN n3.parent_id = 'ROOT' THEN n3.id END,
                CASE WHEN n4.parent_id = 'ROOT' THEN n4.id END,
                CASE WHEN n5.parent_id = 'ROOT' THEN n5.id END,
                CASE WHEN n6.parent_id = 'ROOT' THEN n6.id END
            ) AS level2
        FROM orders o
        JOIN nodes n1 ON o.node_id = n1.id
        LEFT JOIN nodes n2 ON n1.parent_id = n2.id
        LEFT JOIN nodes n3 ON n2.parent_id = n3.id
        LEFT JOIN nodes n4 ON n3.parent_id = n4.id
        LEFT JOIN nodes n5 ON n4.parent_id = n5.id
        LEFT JOIN nodes n6 ON n5.parent_id = n6.id
    ) base
    JOIN (
        -- Menghitung rata-rata dan stddev populasi untuk tiap Manager Level-2
        SELECT 
            level2,
            AVG(nilai_order) AS average,
            STDDEV_POP(nilai_order) AS stdev
        FROM (
            SELECT 
                o.nilai_order,
                COALESCE(
                    CASE WHEN n1.parent_id = 'ROOT' THEN n1.id END,
                    CASE WHEN n2.parent_id = 'ROOT' THEN n2.id END,
                    CASE WHEN n3.parent_id = 'ROOT' THEN n3.id END,
                    CASE WHEN n4.parent_id = 'ROOT' THEN n4.id END,
                    CASE WHEN n5.parent_id = 'ROOT' THEN n5.id END,
                    CASE WHEN n6.parent_id = 'ROOT' THEN n6.id END
                ) AS level2
            FROM orders o
            JOIN nodes n1 ON o.node_id = n1.id
            LEFT JOIN nodes n2 ON n1.parent_id = n2.id
            LEFT JOIN nodes n3 ON n2.parent_id = n3.id
            LEFT JOIN nodes n4 ON n3.parent_id = n4.id
            LEFT JOIN nodes n5 ON n4.parent_id = n5.id
            LEFT JOIN nodes n6 ON n5.parent_id = n6.id
        ) t_stat
        GROUP BY level2
    ) stats ON base.level2 = stats.level2
    WHERE stats.stdev > 0 
      AND ABS((base.nilai_order - stats.average) / stats.stdev) > 3
    GROUP BY base.level2

    UNION ALL

    -- ====================================================================
    -- BAGIAN 2: DETAIL ROWS 
    -- Menampilkan rincian data transaksi outlier
    -- ====================================================================
    SELECT 
        NULL AS level2,
        NULL AS jumlah_anomali,
        base.node_id AS id,
        base.nilai_order AS nilai_order,
        stats.average AS average,
        stats.stdev AS stdev,
        (base.nilai_order - stats.average) AS jarak_average,
        ((base.nilai_order - stats.average) / stats.stdev) AS z_score,
        2 AS sort_type,
        base.level2 AS sort_level2
    FROM (
        SELECT 
            o.no_urut,
            o.node_id,
            o.nilai_order,
            COALESCE(
                CASE WHEN n1.parent_id = 'ROOT' THEN n1.id END,
                CASE WHEN n2.parent_id = 'ROOT' THEN n2.id END,
                CASE WHEN n3.parent_id = 'ROOT' THEN n3.id END,
                CASE WHEN n4.parent_id = 'ROOT' THEN n4.id END,
                CASE WHEN n5.parent_id = 'ROOT' THEN n5.id END,
                CASE WHEN n6.parent_id = 'ROOT' THEN n6.id END
            ) AS level2
        FROM orders o
        JOIN nodes n1 ON o.node_id = n1.id
        LEFT JOIN nodes n2 ON n1.parent_id = n2.id
        LEFT JOIN nodes n3 ON n2.parent_id = n3.id
        LEFT JOIN nodes n4 ON n3.parent_id = n4.id
        LEFT JOIN nodes n5 ON n4.parent_id = n5.id
        LEFT JOIN nodes n6 ON n5.parent_id = n6.id
    ) base
    JOIN (
        SELECT 
            level2,
            AVG(nilai_order) AS average,
            STDDEV_POP(nilai_order) AS stdev
        FROM (
            SELECT 
                o.nilai_order,
                COALESCE(
                    CASE WHEN n1.parent_id = 'ROOT' THEN n1.id END,
                    CASE WHEN n2.parent_id = 'ROOT' THEN n2.id END,
                    CASE WHEN n3.parent_id = 'ROOT' THEN n3.id END,
                    CASE WHEN n4.parent_id = 'ROOT' THEN n4.id END,
                    CASE WHEN n5.parent_id = 'ROOT' THEN n5.id END,
                    CASE WHEN n6.parent_id = 'ROOT' THEN n6.id END
                ) AS level2
            FROM orders o
            JOIN nodes n1 ON o.node_id = n1.id
            LEFT JOIN nodes n2 ON n1.parent_id = n2.id
            LEFT JOIN nodes n3 ON n2.parent_id = n3.id
            LEFT JOIN nodes n4 ON n3.parent_id = n4.id
            LEFT JOIN nodes n5 ON n4.parent_id = n5.id
            LEFT JOIN nodes n6 ON n5.parent_id = n6.id
        ) t_stat
        GROUP BY level2
    ) stats ON base.level2 = stats.level2
    WHERE stats.stdev > 0 
      AND ABS((base.nilai_order - stats.average) / stats.stdev) > 3
) final_output

-- Sortir berdasarkan jenis baris (1=summary, 2=detail) untuk memastikan 
-- summary teratas, diikuti detail per manager.
ORDER BY sort_type ASC, sort_level2 ASC, id ASC;`;

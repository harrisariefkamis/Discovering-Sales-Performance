import React, { useState, useMemo, FormEvent } from "react";
import pptxgen from "pptxgenjs";
import { 
  Database, 
  Presentation, 
  Network, 
  Terminal, 
  Sliders, 
  SlidersHorizontal,
  ChevronRight, 
  AlertTriangle, 
  Plus, 
  Trash2, 
  Check, 
  TrendingUp, 
  Download, 
  Play, 
  HelpCircle, 
  Layers,
  Sparkles,
  RefreshCw,
  FileCheck,
  User,
  GitFork,
  ArrowRight
} from "lucide-react";
import { 
  INITIAL_NODES, 
  INITIAL_ORDERS, 
  executeSqlSimulation, 
  PRESENTATION_SLIDES, 
  RAW_SQL_QUERY,
  ProcessedQueryResult,
  OrderItem,
  NodeItem
} from "./data";

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<"understanding" | "sandbox" | "rca" | "presentation">("understanding");

  // Database Simulator States
  const [nodes, setNodes] = useState<NodeItem[]>(INITIAL_NODES);
  const [orders, setOrders] = useState<OrderItem[]>(INITIAL_ORDERS);
  const [zScoreThreshold, setZScoreThreshold] = useState<number>(3.0);
  
  // Custom Order Entry States
  const [selectedNode, setSelectedNode] = useState<string>("SF_STORE_A");
  const [newOrderValue, setNewOrderValue] = useState<string>("");
  const [newOrderNotes, setNewOrderNotes] = useState<string>("Manual ad-hoc transaction");
  const [newOrderCause, setNewOrderCause] = useState<string>("None - Normal");

  // Presentation Customization States
  const [mainTitle, setMainTitle] = useState<string>("SQL Sales Performance & Anomaly Detection Analysis");
  const [authorName, setAuthorName] = useState<string>("Budi Santoso, Senior Sales Analyst");
  const [activeSlideIdx, setActiveSlideIdx] = useState<number>(0);

  // SQL Query Tab States
  const [sqliteTab, setSqliteTab] = useState<"results" | "query" | "schema">("results");

  // Interactive RCA Actions State
  const [rcaDecisions, setRcaDecisions] = useState<Record<number, { decision: string; justification: string }>>({
    5: { decision: "REJECT_AND_REKEY", justification: "Input error confirmed. Value 48000 is off by exactly 10x multiplier from typical order sizes. Slashed to 4800." },
    11: { decision: "INVESTIGATE_SYSTEM", justification: "Likely a database double-insert glitch within the East Regional billing API. Raised ticket to ERP engineering." },
    19: { decision: "AUDIT_AND_FLAG", justification: "Central store associate bypassed the normal discount limits lock without manager cryptographic key confirmation. Disciplinary action." }
  });

  // Calculate simulated query output
  const queryResult = useMemo(() => {
    // Run mathematical solver that mimics MySQL's calculations
    // Also filters by the customized Z-Score threshold
    const findLevel2 = (nodeId: string): string | null => {
      let current = nodes.find(n => n.id === nodeId);
      if (!current) return null;
      for (let i = 0; i < 6; i++) {
        if (current.parent_id === "ROOT") return current.id;
        const parent = nodes.find(n => n.id === current?.parent_id);
        if (!parent) break;
        current = parent;
      }
      return null;
    };

    const ordersWithLevel2 = orders.map(o => {
      const level2 = findLevel2(o.node_id);
      return { ...o, level2 };
    }).filter(o => o.level2 !== null) as Array<OrderItem & { level2: string }>;

    const statsMap: Record<string, { average: number; stdev: number }> = {};
    const distinctLevel2s = Array.from(new Set(ordersWithLevel2.map(o => o.level2)));

    distinctLevel2s.forEach(lvl2 => {
      const regionOrders = ordersWithLevel2.filter(o => o.level2 === lvl2);
      const sum = regionOrders.reduce((acc, o) => acc + o.nilai_order, 0);
      const average = sum / regionOrders.length;
      const variance = regionOrders.reduce((acc, o) => acc + Math.pow(o.nilai_order - average, 2), 0) / regionOrders.length;
      const stdev = Math.sqrt(variance);
      statsMap[lvl2] = { average, stdev };
    });

    const anomalies = ordersWithLevel2.map(o => {
      const stats = statsMap[o.level2];
      const avg = stats.average;
      const std = stats.stdev;
      const distance = o.nilai_order - avg;
      const z = std > 0 ? distance / std : 0;
      const isAnomaly = std > 0 && Math.abs(z) > zScoreThreshold;

      return {
        ...o,
         average: avg,
         stdev: std,
         jarak_average: distance,
         z_score: z,
         isAnomaly,
      };
    });

    const anomaliesOnly = anomalies.filter(a => a.isAnomaly);

    const summaries: ProcessedQueryResult[] = distinctLevel2s.map(lvl2 => {
      const regionAnomalies = anomaliesOnly.filter(a => a.level2 === lvl2);
      if (regionAnomalies.length === 0) return null;
      return {
        level2: lvl2,
        jumlah_anomali: regionAnomalies.length,
        id: null,
        nilai_order: null,
        average: null,
        stdev: null,
        jarak_average: null,
        z_score: null,
        sort_type: 1,
        sort_level2: lvl2,
      };
    }).filter(s => s !== null) as ProcessedQueryResult[];

    const details: ProcessedQueryResult[] = anomaliesOnly.map(a => {
      return {
        level2: null,
        jumlah_anomali: null,
        id: a.node_id,
        nilai_order: a.nilai_order,
        average: a.average,
        stdev: a.stdev,
        jarak_average: a.jarak_average,
        z_score: a.z_score,
        sort_type: 2,
        sort_level2: a.level2,
      };
    });

    return [...summaries, ...details].sort((a, b) => {
      if (a.sort_type !== b.sort_type) return a.sort_type - b.sort_type;
      if (a.sort_level2 !== b.sort_level2) return a.sort_level2.localeCompare(b.sort_level2);
      const idA = a.id || "";
      const idB = b.id || "";
      return idA.localeCompare(idB);
    });
  }, [nodes, orders, zScoreThreshold]);

  // Handle adding order to database simulator
  const handleAddOrder = (e: FormEvent) => {
    e.preventDefault();
    const val = parseFloat(newOrderValue);
    if (isNaN(val) || val <= 0) return;

    const nextNoUrut = orders.length > 0 ? Math.max(...orders.map(o => o.no_urut)) + 1 : 1;
    const newOrder: OrderItem = {
      no_urut: nextNoUrut,
      node_id: selectedNode,
      nilai_order: val,
      notes: newOrderNotes,
      cause: newOrderCause !== "None - Normal" ? newOrderCause : undefined
    };

    setOrders([...orders, newOrder]);
    setNewOrderValue("");
    setNewOrderNotes("Manual ad-hoc transaction");
    setNewOrderCause("None - Normal");
  };

  // Delete transaction order
  const handleDeleteOrder = (noUrut: number) => {
    setOrders(orders.filter(o => o.no_urut !== noUrut));
  };

  // Reset database back to default state
  const handleResetDb = () => {
    setNodes(INITIAL_NODES);
    setOrders(INITIAL_ORDERS);
    setZScoreThreshold(3.0);
  };

  // Real PPTX file generation
  const handleExportPPTX = () => {
    const pptx = new pptxgen();
    pptx.layout = "LAYOUT_16X9";

    // CSS/HEX colors map for presentation slides
    const COLOR_PRIMARY = "0F172A"; // Slate-900
    const COLOR_TEXT_MUTED = "64748B"; // Slate-500
    const COLOR_TEAL = "0D9488"; // Teal-600
    const COLOR_SKY = "0EA5E9"; // Sky-500
    const COLOR_LIGHT_BG = "F8FAFC"; // Slate-50

    // Slide 1: Cover Slide
    const slideTitle = pptx.addSlide();
    slideTitle.background = { fill: COLOR_PRIMARY };
    
    // Aesthetic structural decorative lines
    slideTitle.addShape(pptx.ShapeType.rect, { 
      x: 0.0, y: 0.0, w: 0.3, h: 7.2, fill: { color: COLOR_TEAL } 
    });

    slideTitle.addText("PORTFOLIO DATA ANALYST CASE STUDY", {
      x: 1.0, y: 1.5, w: 10.0, h: 0.4,
      fontSize: 14, bold: true, color: COLOR_SKY, fontFace: "Georgia"
    });

    slideTitle.addText(mainTitle, {
      x: 1.0, y: 2.0, w: 11.5, h: 1.8,
      fontSize: 34, bold: true, color: "FFFFFF", fontFace: "Arial",
      align: "left"
    });

    slideTitle.addText("A Statistical Approach to Root-Cause Sales Recovery via Z-Score", {
      x: 1.0, y: 3.8, w: 11.5, h: 0.5,
      fontSize: 16, color: "E2E8F0", fontFace: "Arial", italic: true
    });

    slideTitle.addText(`Analyst: ${authorName}\nTools: MySQL v8.0, DBeaver, Statistics, Advanced Hierarchical Maps`, {
      x: 1.0, y: 4.8, w: 11.5, h: 1.2,
      fontSize: 13, color: "94A3B8", fontFace: "Courier New"
    });

    // Slides 2 to 6 loop
    const detailsSlidesToShow = PRESENTATION_SLIDES.slice(1);
    detailsSlidesToShow.forEach((slideItem, index) => {
      const slide = pptx.addSlide();
      slide.background = { fill: COLOR_LIGHT_BG };

      // Left bar styling for visual anchor
      slide.addShape(pptx.ShapeType.rect, { 
        x: 0.4, y: 0.5, w: 0.08, h: 6.2, fill: { color: COLOR_PRIMARY } 
      });

      // Category Badge
      slide.addText(slideItem.badge.toUpperCase(), {
        x: 0.8, y: 0.6, w: 8.0, h: 0.3,
        fontSize: 11, bold: true, color: COLOR_TEAL, fontFace: "Arial"
      });

      // Slide Main Title
      slide.addText(slideItem.title, {
        x: 0.8, y: 0.9, w: 11.5, h: 0.6,
        fontSize: 22, bold: true, color: COLOR_PRIMARY, fontFace: "Arial"
      });

      // Subtitle
      if (slideItem.subtitle) {
        slide.addText(slideItem.subtitle, {
          x: 0.8, y: 1.5, w: 11.5, h: 0.4,
          fontSize: 13, italic: true, color: COLOR_TEXT_MUTED, fontFace: "Arial"
        });
      }

      // Bullets
      slideItem.points.forEach((point, pIdx) => {
        slide.addText(`•   ${point}`, {
          x: 1.0, y: 2.2 + (pIdx * 0.9), w: 11.0, h: 0.8,
          fontSize: 14, color: "1E293B", fontFace: "Arial"
        });
      });

      // Action Decisions included directly into the statistical slide (If slide is Discovery)
      if (slideItem.visualType === "rca") {
        slide.addShape(pptx.ShapeType.rect, {
          x: 1.0, y: 5.2, w: 11.2, h: 1.1,
          fill: { color: "FEF3C7" }, line: { color: "F59E0B", width: 1 }
        });
        slide.addText("EXECUTIVE DECISIONS TAKEN IN WORKSPACE:", {
          x: 1.2, y: 5.3, w: 10.8, h: 0.25,
          fontSize: 10, bold: true, color: "B45309", fontFace: "Arial"
        });
        slide.addText(
          `West Region: Action Taken - ${rcaDecisions[5]?.decision || "REJECT & REKEY"}\n` +
          `East Region: Action Taken - ${rcaDecisions[11]?.decision || "INVESTIGATE GLITCH"}\n` +
          `Central Region: Action Taken - ${rcaDecisions[19]?.decision || "AUDIT DISCOUNT"}`,
          {
            x: 1.2, y: 5.6, w: 10.8, h: 0.6,
            fontSize: 10, color: "78350F", fontFace: "Courier New"
          }
        );
      }

      // Add presentation standard footer
      slide.addText(`Personal Portfolio  |  ${authorName}  |  Slide ${index + 2} of 6`, {
        x: 0.8, y: 6.8, w: 11.5, h: 0.3,
        fontSize: 9, color: COLOR_TEXT_MUTED, fontFace: "Arial", align: "center"
      });
    });

    pptx.writeFile({ fileName: `SQL_Outlier_Analytics_Portfolio.pptx` });
  };

  // Find current visual data stats
  const activeStatsPerRegion = useMemo(() => {
    const stats: Record<string, { avg: number; std: number; count: number; nameStr: string }> = {
      WEST_REG: { avg: 0, std: 0, count: 0, nameStr: "Budi Setiawan (West)" },
      EAST_REG: { avg: 0, std: 0, count: 0, nameStr: "Siti Aminah (East)" },
      CENT_REG: { avg: 0, std: 0, count: 0, nameStr: "Rian Hidayat (Central)" }
    };

    const findLevel2 = (nodeId: string): string | null => {
      let current = nodes.find(n => n.id === nodeId);
      if (!current) return null;
      for (let i = 0; i < 6; i++) {
        if (current.parent_id === "ROOT") return current.id;
        const parent = nodes.find(n => n.id === current?.parent_id);
        if (!parent) break;
        current = parent;
      }
      return null;
    };

    // Calculate normal parameters
    const mapped = orders.map(o => ({ ...o, level2: findLevel2(o.node_id) }));
    
    Object.keys(stats).forEach(rKey => {
      const subset = mapped.filter(o => o.level2 === rKey);
      if (subset.length === 0) return;
      const sum = subset.reduce((acc, currentVal) => acc + currentVal.nilai_order, 0);
      const average = sum / subset.length;
      const variance = subset.reduce((acc, currVal) => acc + Math.pow(currVal.nilai_order - average, 2), 0) / subset.length;
      const stdev = Math.sqrt(variance);

      stats[rKey] = {
        avg: average,
        std: stdev,
        count: subset.length,
        nameStr: stats[rKey].nameStr
      };
    });

    return stats;
  }, [nodes, orders]);

  // Prepare UI render list of orders with their Z-Scores for the sandbox
  const orderListWithZ = useMemo(() => {
    const findLevel2 = (nodeId: string): string | null => {
      let current = nodes.find(n => n.id === nodeId);
      if (!current) return null;
      for (let i = 0; i < 6; i++) {
        if (current.parent_id === "ROOT") return current.id;
        const parent = nodes.find(n => n.id === current?.parent_id);
        if (!parent) break;
        current = parent;
      }
      return null;
    };

    return orders.map(o => {
      const lvl2 = findLevel2(o.node_id) || "UNKNOWN";
      const stats = activeStatsPerRegion[lvl2] || { avg: 0, std: 0 };
      const dev = o.nilai_order - stats.avg;
      const z = stats.std > 0 ? dev / stats.std : 0;
      return {
        ...o,
        level2: lvl2,
        avg: stats.avg,
        std: stats.std,
        zScore: z,
        isAnomaly: Math.abs(z) > zScoreThreshold
      };
    });
  }, [orders, nodes, activeStatsPerRegion, zScoreThreshold]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-slate-950 text-xs">
      
      {/* Dynamic Upper Enterprise Banner */}
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-50 px-4 py-2">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="bg-teal-500/10 text-teal-400 p-1.5 rounded border border-teal-500/25">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-extrabold tracking-tight text-white flex items-center gap-2">
                SQL Anomaly Portfolio Builder 
                <span className="text-[10px] bg-teal-500/15 text-teal-300 px-1.5 py-0.5 rounded border border-teal-400/20 font-mono">
                  MySQL 8.0 StdDev POP
                </span>
              </h1>
              <p className="text-[10px] text-slate-400">
                Berdasarkan Case Study Anomali Penjualan Regional - Interaktif Z-Score Analisis
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <div className="flex items-center bg-slate-950 px-2 py-1 rounded border border-slate-800 text-[10px] font-mono text-slate-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse mr-1.5"></span>
              Workspace: ACTIVE_SIMULATOR
            </div>
            
            <button
              onClick={handleResetDb}
              title="Reset Simulated Database"
              className="px-2 py-1 text-[10px] text-red-400 hover:text-red-300 bg-red-950/25 hover:bg-red-950/45 border border-red-900/40 rounded transition-all flex items-center gap-1 cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              Reset DB (Default)
            </button>
          </div>
        </div>
      </header>

      {/* Hero Overview Pitch Stats */}
      <section className="bg-gradient-to-r from-slate-900 via-slate-950 to-slate-900 border-b border-slate-800 py-3 px-4">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-3">
          <div className="bg-slate-900/60 p-3 rounded-md border border-slate-800/80">
            <div className="text-slate-400 text-[10px] font-mono uppercase tracking-wider">Total Evaluated Transactions</div>
            <div className="text-lg font-bold text-white mt-0.5">{orders.length} Rows</div>
            <div className="text-[10px] text-teal-400 mt-0.5 font-mono">Mapped dynamically across 6 nodes deep</div>
          </div>
          <div className="bg-slate-900/60 p-3 rounded-md border border-slate-800/80">
            <div className="text-slate-400 text-[10px] font-mono uppercase tracking-wider">Detected Anomaly Outliers</div>
            <div className="text-lg font-bold text-rose-400 mt-0.5">
              {orderListWithZ.filter(o => o.isAnomaly).length} Anomalies
            </div>
            <div className="text-[10px] text-rose-300 mt-0.5 font-mono">Z-Score threshold limits &gt; {zScoreThreshold}</div>
          </div>
          <div className="bg-slate-900/60 p-3 rounded-md border border-slate-800/80">
            <div className="text-slate-400 text-[10px] font-mono uppercase tracking-wider">Active Regional Baselines</div>
            <div className="text-lg font-bold text-teal-400 mt-0.5">3 Divisions</div>
            <div className="text-[10px] text-slate-400 mt-0.5">West Region, East Region, Central Region</div>
          </div>
          <div className="bg-slate-900/60 p-3 rounded-md border border-slate-800/80 flex flex-col justify-between">
            <div>
              <div className="text-slate-400 text-[10px] font-mono uppercase tracking-wider">Statistical Standardizer</div>
              <div className="text-[10px] text-white mt-1 font-mono bg-blue-950/40 text-blue-300 border border-blue-900/40 rounded px-1.5 py-0.5">
                ABS((nilai - avg) / PopStd) &gt; {zScoreThreshold}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 flex flex-col lg:flex-row gap-4">
        
        {/* Left Side Navigation Control Panel */}
        <div className="w-full lg:w-56 shrink-0 flex flex-col gap-1.5">
          
          <div className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider px-2 mb-1.5">STEPS INTERACTIF DECK</div>
          
          <button
            onClick={() => setActiveTab("understanding")}
            className={`w-full text-left px-3 py-2 rounded-md border transition-all duration-150 flex items-center justify-between group ${
              activeTab === "understanding" 
                ? "bg-teal-950/40 border-teal-500/30 border-l-2 border-l-teal-400 text-white font-semibold" 
                : "bg-slate-900/45 border-slate-900/60 text-slate-400 hover:bg-slate-900 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2">
              <div className={`p-1 rounded ${activeTab === 'understanding' ? 'bg-teal-550/25 text-teal-400' : 'bg-slate-800 text-slate-500'}`}>
                <Network className="w-3.5 h-3.5" />
              </div>
              <span className="text-[11px]">1. Data Structure UI</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:translate-x-0.5 transition-transform" />
          </button>

          <button
            onClick={() => setActiveTab("sandbox")}
            className={`w-full text-left px-3 py-2 rounded-md border transition-all duration-150 flex items-center justify-between group ${
              activeTab === "sandbox" 
                ? "bg-teal-950/40 border-teal-500/30 border-l-2 border-l-teal-400 text-white font-semibold" 
                : "bg-slate-900/45 border-slate-900/60 text-slate-400 hover:bg-slate-900 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2">
              <div className={`p-1 rounded ${activeTab === 'sandbox' ? 'bg-teal-550/25 text-teal-400' : 'bg-slate-800 text-slate-500'}`}>
                <Terminal className="w-3.5 h-3.5" />
              </div>
              <span className="text-[11px]">2. Database Sandbox</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:translate-x-0.5 transition-transform" />
          </button>

          <button
            onClick={() => setActiveTab("rca")}
            className={`w-full text-left px-3 py-2 rounded-md border transition-all duration-150 flex items-center justify-between group ${
              activeTab === "rca" 
                ? "bg-teal-950/40 border-teal-500/30 border-l-2 border-l-teal-400 text-white font-semibold" 
                : "bg-slate-900/45 border-slate-900/60 text-slate-400 hover:bg-slate-900 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2">
              <div className={`p-1 rounded ${activeTab === 'rca' ? 'bg-teal-550/25 text-teal-400' : 'bg-slate-800 text-slate-500'}`}>
                <AlertTriangle className="w-3.5 h-3.5" />
              </div>
              <span className="text-[11px]">3. RCA Decision Maker</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:translate-x-0.5 transition-transform" />
          </button>

          <button
            onClick={() => setActiveTab("presentation")}
            className={`w-full text-left px-3 py-2 rounded-md border transition-all duration-150 flex items-center justify-between group ${
              activeTab === "presentation" 
                ? "bg-teal-950/40 border-teal-500/30 border-l-2 border-l-teal-400 text-white font-semibold" 
                : "bg-slate-900/45 border-slate-900/60 text-slate-400 hover:bg-slate-900 hover:text-slate-200"
            }`}
          >
            <div className="flex items-center gap-2">
              <div className={`p-1 rounded ${activeTab === 'presentation' ? 'bg-teal-550/25 text-teal-400' : 'bg-slate-800 text-slate-500'}`}>
                <Presentation className="w-3.5 h-3.5" />
              </div>
              <span className="text-[11px]">4. Slide Exporter .PPT</span>
            </div>
            <ChevronRight className="w-3.5 h-3.5 text-slate-600 group-hover:translate-x-0.5 transition-transform" />
          </button>

          <div className="mt-4 bg-slate-900/40 p-3 rounded-md border border-slate-800/80">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">METODE TERAPAN</h4>
            <ul className="text-[10px] text-slate-400 mt-1.5 space-y-1 list-disc pl-3 font-mono">
              <li>Adjacency Tree Map</li>
              <li>COALESCE level flatten</li>
              <li>STDDEV_POP stat group</li>
              <li>Z-Score outlier trigger</li>
            </ul>
          </div>
        </div>

        {/* Right Side Main Interactive Workspace Content */}
        <div className="flex-1 min-w-0">

          {/* TAB 1: DATA UNDERSTANDING & ORGANIZATION ARCHITECTURE */}
          {activeTab === "understanding" && (
            <div className="space-y-4">
              
              {/* Executive Objective Summary */}
              <div className="bg-gradient-to-b from-slate-900 to-slate-950 p-4 rounded-lg border border-slate-800">
                <div className="flex items-center gap-1.5 text-teal-400 font-mono text-[10px] uppercase tracking-wider mb-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  Understanding the Corporate Business Hierarchy
                </div>
                <h3 className="text-base font-bold text-white mb-2 leading-snug border-l-2 border-teal-400 pl-2">
                  Bagaimana Query Mengatasi Hierarki Database 6 Level Penting?
                </h3>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Di dalam sistem ritel korporat atau rantai pasok multi-level, setiap pesanan penjualan ditempatkan pada level toko paling bawah. Namun, untuk evaluasi anomali, setiap transaksi harus di-grouping berdasarkan penanggung jawab tertinggi di area regional tersebut (Manager Level-2). Di MySQL, query ini secara efisien memecahkan hierarki tanpa rekursif CTE yang berat dengan cara menggunakan teknik urutan <strong>LEFT JOIN beruntun</strong> dan dievaluasi searah menggunakan <strong>COALESCE</strong>.
                </p>
              </div>

              {/* Data Visualization Grid: Interactive Hierarchy Tree */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Visual Tree diagram of Nodes in memory */}
                <div className="bg-slate-900/40 p-4 rounded-lg border border-slate-800/80 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-extrabold text-white uppercase tracking-wider mb-1.5 border-l-2 border-teal-400 pl-2">
                      Struktur Hierarki Organisasi (Adjacency List)
                    </h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed mb-3">
                      Rantai birokrasi dari Root (Pusat) hingga toko kasir langsung. Arah panah menunjukkan pelaporan (parent_id) yang dibaca query MySQL.
                    </p>

                    {/* Hierarchy Flow Chart Card */}
                    <div className="bg-slate-950 p-3 rounded border border-slate-900 space-y-2.5 font-mono text-[10px] text-slate-300 overflow-x-auto">
                      <div className="flex items-center gap-2">
                        <span className="px-1.5 py-0.5 bg-blue-950 text-blue-300 rounded border border-blue-900/40">Level 1</span>
                        <span className="text-slate-450 font-sans">Corporate Node:</span>
                        <strong className="text-white">ROOT</strong>
                      </div>
                      <div className="pl-4 border-l border-slate-800 space-y-2.5 py-1">
                        
                        {/* West region branch */}
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 bg-teal-950/80 text-teal-300 rounded border border-teal-900/40">Level-2 (Reg)</span>
                            <span className="text-teal-400 font-bold">WEST_REG</span>
                            <span className="text-slate-500 font-sans">(Budi Setiawan)</span>
                          </div>
                          <div className="pl-4 border-l border-teal-900/50 py-0.5 space-y-0.5">
                            <div className="flex items-center gap-1">
                              <span className="text-slate-500">L3:</span>
                              <span className="text-slate-400">CA_AREA</span>
                              <span className="text-slate-500">→</span>
                              <span className="text-slate-450">SF_BRANCH</span>
                              <span className="text-slate-500">→</span>
                              <span className="text-emerald-400 font-semibold">SF_STORE_A (Orders)</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <span className="text-slate-500">L3:</span>
                              <span className="text-slate-400">CA_AREA</span>
                              <span className="text-slate-500">→</span>
                              <span className="text-slate-450">LA_BRANCH</span>
                              <span className="text-slate-500">→</span>
                              <span className="text-slate-350">LA_STORE_A</span>
                            </div>
                          </div>
                        </div>

                        {/* East region branch */}
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 bg-teal-950/80 text-teal-300 rounded border border-teal-900/40">Level-2 (Reg)</span>
                            <span className="text-teal-400 font-bold">EAST_REG</span>
                            <span className="text-slate-500 font-sans">(Siti Aminah)</span>
                          </div>
                          <div className="pl-4 border-l border-teal-900/50 py-0.5">
                            <div className="flex items-center gap-1">
                              <span className="text-slate-500">L3:</span>
                              <span className="text-slate-400">NY_AREA</span>
                              <span className="text-slate-500">→</span>
                              <span className="text-slate-450">NYC_BRANCH</span>
                              <span className="text-slate-500">→</span>
                              <span className="text-emerald-400 font-semibold">NY_STORE_A (Orders)</span>
                            </div>
                          </div>
                        </div>

                        {/* Central region branch */}
                        <div className="space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 bg-teal-950/80 text-teal-300 rounded border border-teal-900/40">Level-2 (Reg)</span>
                            <span className="text-teal-400 font-bold">CENT_REG</span>
                            <span className="text-slate-500 font-sans">(Rian Hidayat)</span>
                          </div>
                          <div className="pl-4 border-l border-teal-900/50 py-0.5">
                            <div className="flex items-center gap-1">
                              <span className="text-slate-500">L3:</span>
                              <span className="text-slate-400">IL_AREA</span>
                              <span className="text-slate-500">→</span>
                              <span className="text-slate-450">CHI_BRANCH</span>
                              <span className="text-slate-500">→</span>
                              <span className="text-emerald-400 font-semibold">CHI_STORE_A (Orders)</span>
                            </div>
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-3 pt-2.5 border-t border-slate-800">
                    <p className="text-[10px] text-slate-400 flex items-center gap-1.5 italic">
                      <HelpCircle className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                      COALESCE menelusuri naik 6 level untuk melacak Regional VP direktori langsung di bawah ROOT.
                    </p>
                  </div>
                </div>

                {/* Statistical Formula Card */}
                <div className="bg-slate-900/40 p-4 rounded-lg border border-slate-800/80 flex flex-col justify-between">
                  <div>
                    <h4 className="text-xs font-extrabold text-white uppercase tracking-wider mb-1.5 border-l-2 border-teal-400 pl-2">
                      Metode Matematika: Analisis Z-Score
                    </h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed mb-3">
                      Menggunakan Statistik Deviasi Standar Populasi demi keakuratan mutlak dalam mengisolasi data anomalitas operasional.
                    </p>

                    <div className="space-y-2.5">
                      <div className="bg-slate-950 p-2.5 rounded border border-slate-900">
                        <div className="text-[10px] text-slate-400 mb-0.5">1. Rata-rata Kelompok Ritel (μ)</div>
                        <div className="text-[11px] font-mono text-emerald-450 font-bold">μ = (Σ Order Nilai) / N</div>
                        <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                          Menghitung rata-rata nilai transaksi dalam satu regional pimpinan Manager Level-2 tertentu.
                        </p>
                      </div>

                      <div className="bg-slate-950 p-2.5 rounded border border-slate-900">
                        <div className="text-[10px] text-slate-400 mb-0.5">2. Standar Deviasi Populasi (σ)</div>
                        <div className="text-[11px] font-mono text-teal-400 font-bold">σ = √[ Σ(x - μ)² / N ]</div>
                        <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">
                          Menggunakan fungsi bawaan <code>STDDEV_POP</code> di MySQL untuk mengetahui penyebaran luas data normal transaksi.
                        </p>
                      </div>

                      <div className="bg-slate-950 p-2.5 rounded border border-slate-900">
                        <div className="text-[10px] text-slate-400 mb-0.5">3. Formula Hitung Z-Score</div>
                        <div className="text-[11px] font-mono text-rose-450 font-bold">Z = (x - μ) / σ</div>
                        <p className="text-[10px] text-slate-450 mt-0.5 leading-relaxed">
                          Outlier mutlak terdeteksi secara otomatis bila nilai absolut Z-Score melampaui rentang batas normal: <strong>|Z| &gt; {zScoreThreshold}</strong>.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-3">
                    <button 
                      onClick={() => setActiveTab("sandbox")}
                      className="w-full text-center py-1.5 bg-teal-500 hover:bg-teal-400 text-slate-950 font-bold rounded text-[11px] transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      Buka Database Simulator & Query Runner
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

              </div>

              {/* Step Process Presentation Slides Visual Overview */}
              <div className="bg-slate-900/25 p-4 rounded-lg border border-slate-800">
                <h4 className="text-xs font-bold text-white mb-2 uppercase tracking-wide border-l-2 border-teal-400 pl-2">Gambaran Alur Kerja End-To-End</h4>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-2 text-[10px] font-mono">
                  <div className="bg-slate-950 p-3 rounded border border-slate-900 space-y-1">
                    <div className="text-teal-400 font-bold">Langkah 01</div>
                    <div className="text-white font-semibold flex items-center gap-1">Extract & Flatten</div>
                    <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
                      Melacak relasi parent_id dari order leaf node ke Level-2 pimpinan regional.
                    </p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded border border-slate-900 space-y-1">
                    <div className="text-teal-400 font-bold">Langkah 02</div>
                    <div className="text-white font-semibold">Populate Aggregates</div>
                    <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
                      Menghitung baseline teoretis AVG dan STDDEV_POP per regional manager kelompok.
                    </p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded border border-slate-900 space-y-1">
                    <div className="text-teal-400 font-bold">Langkah 03</div>
                    <div className="text-white font-semibold">Evaluate Z-Scores</div>
                    <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
                      Mengonversi seluruh nilai numerik ke dalam bentuk deviasi standar standar dbeaver.
                    </p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded border border-slate-900 space-y-1">
                    <div className="text-teal-400 font-bold">Langkah 04</div>
                    <div className="text-white font-semibold">Union All & Action</div>
                    <p className="text-[10px] text-slate-400 font-sans leading-relaxed">
                      Menyajikan executive summary counts dan data baris outlier ber-nilai ekstrem.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: INTERACTIVE DATABASE SANDBOX & QUERY RUNNER */}
          {activeTab === "sandbox" && (
            <div className="space-y-4">
              
              <div className="bg-slate-900/40 p-3.5 rounded-lg border border-slate-800">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5 border-l-2 border-teal-400 pl-2">
                      <Terminal className="text-teal-400 w-4 h-4" />
                      Dynamic Database Simulator Pane
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Mulai memodifikasi nilai pesanan secara langsung untuk mempelajari pergeseran Standard Deviation di MySQL secara dinamis.
                    </p>
                  </div>

                  {/* Threshold Adjuster slider */}
                  <div className="bg-slate-950 p-2 rounded-md border border-slate-800/80 w-full md:w-56 shrink-0">
                    <div className="flex justify-between text-[10px] font-mono text-slate-400 mb-1">
                      <span>Batas Z-Score Threshold:</span>
                      <span className="text-rose-400 font-bold">{zScoreThreshold.toFixed(1)} σ</span>
                    </div>
                    <input 
                      type="range" 
                      min="1.5" 
                      max="4.0" 
                      step="0.1" 
                      value={zScoreThreshold} 
                      onChange={(e) => setZScoreThreshold(parseFloat(e.target.value))}
                      className="w-full h-1.5 accent-teal-500 cursor-pointer bg-slate-850 rounded-lg appearance-none"
                    />
                    <div className="flex justify-between text-[8px] text-slate-500 font-mono mt-0.5">
                      <span>Sensitif (1.5)</span>
                      <span>Default (3.0)</span>
                      <span>Ketat (4.0)</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Simulation Sandbox Grid */}
              <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
                
                {/* Custom Order adder & current orders list */}
                <div className="xl:col-span-12 lg:xl:col-span-5 space-y-4">
                  
                  {/* Form to insert orders to the state */}
                  <div className="bg-slate-900/40 p-4 rounded-lg border border-slate-800">
                    <h4 className="text-[11px] font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-1.5 border-l-2 border-teal-400 pl-1.5">
                      <Plus className="w-3.5 h-3.5 text-teal-400" />
                      Insert Custom Transaction Order Row
                    </h4>

                    <form onSubmit={handleAddOrder} className="space-y-3">
                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase font-mono mb-0.5">Target Leaf Node (Store Front):</label>
                        <select 
                          value={selectedNode} 
                          onChange={(e) => setSelectedNode(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-md text-[10px] font-mono text-white focus:outline-none focus:border-teal-500"
                        >
                          <option value="SF_STORE_A">SF Store Alpha (West VP: Budi Setiawan)</option>
                          <option value="LA_STORE_A">LA Store Alpha (West VP: Budi Setiawan)</option>
                          <option value="NY_STORE_A">NY Store Alpha (East VP: Siti Aminah)</option>
                          <option value="CHI_STORE_A">Chicago Store Alpha (Central VP: Rian Hidayat)</option>
                        </select>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[10px] text-slate-400 uppercase font-mono mb-0.5">Nilai Penjualan ($):</label>
                          <input 
                            type="number" 
                            placeholder="e.g. 52000" 
                            value={newOrderValue}
                            onChange={(e) => setNewOrderValue(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-md text-[10px] font-mono text-white focus:outline-none focus:border-teal-500"
                            required
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] text-slate-400 uppercase font-mono mb-0.5">Business Cause Tag:</label>
                          <select 
                            value={newOrderCause}
                            onChange={(e) => setNewOrderCause(e.target.value)}
                            className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-md text-[10px] font-mono text-slate-300 focus:outline-none focus:border-teal-500"
                          >
                            <option value="None - Normal">None - Normal</option>
                            <option value="Human Input Error">Human Input Error</option>
                            <option value="System Glitch / Double Billing">System Glitch</option>
                            <option value="Unauthorized Staff Override">Staff Override Auth</option>
                            <option value="VIP Commercial Order">VIP Mega Order</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[10px] text-slate-400 uppercase font-mono mb-0.5">Transaction Label/Notes:</label>
                        <input 
                          type="text" 
                          placeholder="Short description..." 
                          value={newOrderNotes}
                          onChange={(e) => setNewOrderNotes(e.target.value)}
                          className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded-md text-[10px] text-white focus:outline-none focus:border-teal-500"
                        />
                      </div>

                      <button 
                        type="submit"
                        className="w-full py-1.5 bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-400 hover:to-emerald-400 text-slate-950 font-bold rounded text-[11px] transition-colors cursor-pointer"
                      >
                        Simulasikan Transaksi & Refresh Metrics
                      </button>
                    </form>
                  </div>

                  {/* Simulated Table Data inputs in memory */}
                  <div className="bg-slate-900/40 rounded-lg border border-slate-800 overflow-hidden">
                    <div className="px-3 py-2 bg-slate-900/60 border-b border-slate-800 flex justify-between items-center">
                      <span className="text-[10px] font-extrabold text-white uppercase tracking-wider font-mono">
                        📊 Current Database Grid ({orderListWithZ.length} Records)
                      </span>
                      <span className="text-[9px] text-slate-500 font-mono">Simulated RAM</span>
                    </div>

                    <div className="overflow-y-auto max-h-64 text-[10px] text-slate-300">
                      <table className="w-full text-left font-mono">
                        <thead className="bg-slate-950 text-[9px] text-slate-500 uppercase">
                          <tr>
                            <th className="px-2.5 py-1.5">ID</th>
                            <th className="px-2.5 py-1.5">Store Node</th>
                            <th className="px-2.5 py-1.5 text-right">Order ($)</th>
                            <th className="px-2.5 py-1.5">Z-Score</th>
                            <th className="px-2.5 py-1.5 text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-850/60">
                          {orderListWithZ.map((o) => (
                            <tr key={o.no_urut} className={`hover:bg-slate-900/40 transition-colors ${o.isAnomaly ? 'bg-rose-950/15 text-rose-200' : ''}`}>
                              <td className="px-2.5 py-1 font-semibold text-slate-400">#{o.no_urut}</td>
                              <td className="px-2.5 py-1">
                                <span className="block font-sans text-white text-[10px] leading-tight">{o.node_id}</span>
                                <span className="block text-[8px] text-slate-500 max-w-[120px] truncate">{o.notes}</span>
                              </td>
                              <td className="px-2.5 py-1 text-right font-bold text-slate-200">
                                ${o.nilai_order.toLocaleString()}
                              </td>
                              <td className="px-2.5 py-1">
                                <span className={`px-1 rounded-sm font-bold text-[9px] ${o.isAnomaly ? 'bg-rose-900/40 text-rose-300 border border-rose-900/50' : 'bg-slate-900 text-slate-400'}`}>
                                  {o.zScore > 0 ? "+" : ""}{o.zScore.toFixed(2)}
                                </span>
                              </td>
                              <td className="px-2.5 py-1 text-right">
                                <button 
                                  onClick={() => handleDeleteOrder(o.no_urut)}
                                  className="text-slate-500 hover:text-red-400 hover:bg-slate-800/60 p-1 rounded transition-all cursor-pointer"
                                  title="Delete Transaction Record"
                                >
                                  <Trash2 className="w-3 h-3" />
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                </div>

                {/* Output Query view vs raw SQL Query */}
                <div className="xl:col-span-12 lg:xl:col-span-7 space-y-4">
                  
                  {/* Tabs for query explorer */}
                  <div className="border-b border-slate-800 flex justify-between items-center bg-slate-950 rounded-md p-1 border">
                    <div className="flex gap-1">
                      <button 
                        onClick={() => setSqliteTab("results")}
                        className={`px-3 py-1.5 rounded text-[11px] font-mono transition-all flex items-center gap-1 cursor-pointer ${sqliteTab === "results" ? 'bg-teal-950/50 text-teal-400 border border-teal-850 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
                      >
                        <Database className="w-3.5 h-3.5" />
                        Execution Results Output
                      </button>
                      <button 
                        onClick={() => setSqliteTab("query")}
                        className={`px-3 py-1.5 rounded text-[11px] font-mono transition-all flex items-center gap-1 cursor-pointer ${sqliteTab === "query" ? 'bg-teal-950/50 text-teal-400 border border-teal-850 font-bold' : 'text-slate-400 hover:text-slate-200'}`}
                      >
                        <Terminal className="w-3.5 h-3.5" />
                        Dissect SQL Code (Color/Syntax)
                      </button>
                    </div>

                    <span className="text-[9px] text-slate-500 font-mono pr-2">MySQL Workbench 8.0 Mode</span>
                  </div>

                  {/* sqliteTab 1: Simulated SQL output results */}
                  {sqliteTab === "results" && (
                    <div className="space-y-3">
                      
                      <div className="bg-slate-900/40 p-3.5 rounded-lg border border-slate-800">
                        <div className="flex justify-between items-center mb-2.5">
                          <h4 className="text-[11px] font-extrabold text-white font-mono flex items-center gap-1.5 border-l-2 border-teal-400 pl-1.5">
                            <span className="w-2 h-2 rounded-full bg-teal-400 animate-pulse"></span>
                            Result Set - MySQL Query Solver Output
                          </h4>
                          <span className="text-[10px] text-slate-400 font-mono">Affected rows: {queryResult.length} Rows</span>
                        </div>

                        {queryResult.length === 0 ? (
                          <div className="py-8 text-center text-slate-500 font-mono text-[11px] space-y-1">
                            <SlidersHorizontal className="w-8 h-8 stroke-1 mx-auto text-slate-600 animate-pulse" />
                            <p>No active outliers evaluated below threshold limit Z={zScoreThreshold}</p>
                            <p className="text-[10px] text-slate-600">Tip: Coba turunkan slider threshold ke 1.8 σ atau simulasikan order besar baru!</p>
                          </div>
                        ) : (
                          <div className="overflow-x-auto border border-slate-850 rounded bg-slate-950 font-mono text-[10px]">
                            <table className="w-full text-left">
                              <thead className="bg-slate-900 text-slate-400 text-[9px] uppercase tracking-wider">
                                <tr>
                                  <th className="px-2 py-1.5 border-b border-slate-850">level2</th>
                                  <th className="px-2 py-1.5 border-b border-slate-850 text-right">jumlah_anomali</th>
                                  <th className="px-2 py-1.5 border-b border-slate-850">id (node)</th>
                                  <th className="px-2 py-1.5 border-b border-slate-850 text-right">nilai_order ($)</th>
                                  <th className="px-2 py-1.5 border-b border-slate-850 text-right">average ($)</th>
                                  <th className="px-2 py-1.5 border-b border-slate-850 text-right">stdev (σ)</th>
                                  <th className="px-2 py-1.5 border-b border-slate-850 text-right">z_score</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-900">
                                {queryResult.map((row, idx) => {
                                  const isSummary = row.sort_type === 1;
                                  return (
                                    <tr key={idx} className={isSummary ? "bg-teal-950/20 text-teal-300 font-bold" : "hover:bg-slate-900/60 text-slate-300"}>
                                      <td className="px-2 py-1 text-slate-200">
                                        {row.level2 || <span className="text-slate-650">—</span>}
                                      </td>
                                      <td className="px-2 py-1 text-right">
                                        {row.jumlah_anomali !== null ? (
                                          <span className="px-1.5 py-0.5 bg-teal-950/80 text-teal-400 rounded border border-teal-900/40">
                                            {row.jumlah_anomali}
                                          </span>
                                        ) : <span className="text-slate-650">—</span>}
                                      </td>
                                      <td className="px-2 py-1 text-white">
                                        {row.id || <span className="text-slate-650">—</span>}
                                      </td>
                                      <td className="px-2 py-1 text-right font-bold font-sans text-sky-200">
                                        {row.nilai_order !== null ? `$${row.nilai_order.toLocaleString()}` : <span className="text-slate-650 font-mono">—</span>}
                                      </td>
                                      <td className="px-2 py-1 text-right text-slate-400 font-sans">
                                        {row.average !== null ? `$${Math.round(row.average).toLocaleString()}` : <span className="text-slate-650 font-mono">—</span>}
                                      </td>
                                      <td className="px-2 py-1 text-right text-slate-400 font-sans">
                                        {row.stdev !== null ? `${Math.round(row.stdev).toLocaleString()}` : <span className="text-slate-650 font-mono">—</span>}
                                      </td>
                                      <td className="px-2 py-1 text-right">
                                        {row.z_score !== null ? (
                                          <span className="text-rose-450 font-bold bg-rose-950/40 px-1 rounded">
                                            {row.z_score > 0 ? "+" : ""}{row.z_score.toFixed(2)}
                                          </span>
                                        ) : <span className="text-slate-650">—</span>}
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        )}
                      </div>

                      {/* Explanation box on matching simulated mathematical operations */}
                      <div className="bg-yellow-500/10 border border-yellow-500/20 p-4 rounded-lg text-[10px] text-yellow-200 leading-relaxed space-y-1.5">
                        <h5 className="font-extrabold font-mono text-yellow-400 flex items-center gap-1.5 uppercase">
                          <AlertTriangle className="w-3.5 h-3.5" />
                          PEMBAHASAN TEKNIS EKSEKUSI DATA SET
                        </h5>
                        <p>
                          Hasil set di atas terbagi secara akurat menjadi 2 layer logis:
                        </p>
                        <ol className="list-decimal pl-4 space-y-0.5">
                          <li><strong>Summary Rows (Bagian 1):</strong> Menghitung total transaksi anomali perkiraannya per tiap regional manager di level COALESCE teratas.</li>
                          <li><strong>Detail Rows (Bagian 2):</strong> Menjajarkan baris data asli pemicu kegagalan baseline, dikalkulasikan z-score individu terhadap rata-rata manager regionalnya masing-masing.</li>
                        </ol>
                        <p className="text-[9px] text-yellow-350 italic">
                          Menggunakan sorting <code>ORDER BY sort_type ASC, sort_level2 ASC</code> menjamin summary regional diletakkan persis di atas jajaran rincian data outlier-nya masing-masing di display software DBeaver Anda!
                        </p>
                      </div>

                    </div>
                  )}

                  {/* sqliteTab 2: Raw SQL query code syntax editor */}
                  {sqliteTab === "query" && (
                    <div className="space-y-4">
                      <div className="bg-slate-900/40 p-4 rounded-lg border border-slate-800 flex flex-col">
                        <div className="flex justify-between items-center mb-2.5">
                          <span className="text-[10px] text-slate-400 font-mono">DBeaver SQL Dialect: MySQL 8.0 Standard</span>
                          <button 
                            onClick={() => navigator.clipboard.writeText(RAW_SQL_QUERY)}
                            className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px] px-2 py-0.5 rounded transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Check className="w-3 h-3 text-teal-400" />
                            Copy SQL Query
                          </button>
                        </div>
                        
                        <pre className="text-slate-300 font-mono text-[10px] leading-relaxed overflow-x-auto bg-slate-950 p-3 rounded border border-slate-900 max-h-[400px]">
                          <code>{RAW_SQL_QUERY}</code>
                        </pre>
                      </div>
                    </div>
                  )}

                </div>
              </div>
            </div>
          )}

          {/* TAB 3: BUSINESS PROBLEM SOLVING & RCA EXECUTIVE DECISION CANVAS */}
          {activeTab === "rca" && (
            <div className="space-y-4">
              
              <div className="bg-gradient-to-b from-slate-900 to-slate-950 p-3.5 rounded-lg border border-slate-800">
                <h3 className="text-sm font-bold text-white flex items-center gap-1.5 border-l-2 border-teal-400 pl-2">
                  <FileCheck className="text-teal-400 w-4 h-4" />
                  RCA Investigator & Decision-Making Canvas
                </h3>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
                  Data saja tidak bernilai komersial tanpa adanya interpretasi bisnis / pengambilan keputusan. Sebagai <strong>Senior Business Data Analyst</strong>, tugas Anda adalah mengonversi data anomali statistik (|Z| &gt; 3.0) di atas ke dalam pemecahan masalah (Problem Solving) operasional bisnis yang nyata.
                </p>
              </div>

              {/* Dynamic Interactive Investigators list */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* Outlier Case 1: West Region Budi Setiawan */}
                <div className="bg-slate-900/40 p-4 rounded-lg border border-slate-800/80 flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] font-mono bg-rose-950/80 text-rose-300 px-2 py-0.5 rounded border border-rose-900/50">
                      Z Score: +5.83 σ (Extremely Extreme)
                    </span>
                    <h4 className="text-sm font-bold text-white mt-2.5 inline-block border-b border-teal-500/20 pb-0.5">
                      Budi Setiawan (West)
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-0.5 font-mono">Store Terminal: SF_STORE_A</p>

                    <div className="mt-3 p-2.5 bg-slate-950 rounded border border-slate-900 text-[10px]">
                      <div className="text-slate-500 uppercase font-mono tracking-wider text-[8px]">Anomalous Value:</div>
                      <div className="text-base font-bold text-sky-355 font-mono mt-0.5">$48,000.00</div>
                      <div className="text-slate-400 mt-1.5 font-sans italic leading-tight">
                        "Data audit menunjukkan rata-rata penjualan toko SF_STORE_A berkisar $3,000. Invoice terbit sebesar $48,000 diduga kuat merupakan Human Error (Fat-Finger typo memasukkan satu angka nol berlebih)."
                      </div>
                    </div>

                    <div className="mt-3 space-y-1">
                      <label className="block text-[9px] text-slate-400 font-mono uppercase">Action Decision taken:</label>
                      <select 
                        value={rcaDecisions[5]?.decision}
                        onChange={(e) => setRcaDecisions({
                          ...rcaDecisions,
                          5: { ...rcaDecisions[5], decision: e.target.value }
                        })}
                        className="w-full bg-slate-950 border border-slate-800 px-2 py-1 rounded text-[10px] font-mono text-white focus:outline-none focus:border-teal-500"
                      >
                        <option value="REJECT_AND_REKEY">REJECT & REKEY (Void & input ulang $4,800)</option>
                        <option value="APPROVE_AS_VIP">APPROVE (VIP Commercial Super Deal Sales)</option>
                        <option value="FLAG_FOR_AUDIT">FLAG (Kirim Tim Auditor Kepatuhan Lapangan)</option>
                      </select>
                    </div>

                    <div className="mt-2.5">
                      <label className="block text-[9px] text-slate-550 font-mono uppercase">Justifikasi Analistik:</label>
                      <textarea
                        value={rcaDecisions[5]?.justification}
                        onChange={(e) => setRcaDecisions({
                          ...rcaDecisions,
                          5: { ...rcaDecisions[5], justification: e.target.value }
                        })}
                        className="w-full h-16 bg-slate-950 border border-slate-800 p-1.5 text-[10px] rounded mt-0.5 text-slate-300 focus:outline-none focus:border-teal-500 font-sans"
                      />
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-850 text-[9px] text-slate-500 italic flex items-center gap-1">
                    <Check className="w-3 h-3 text-teal-400" />
                    Action integrated into portfolio deck
                  </div>
                </div>

                {/* Outlier Case 2: East Region Siti Aminah */}
                <div className="bg-slate-900/40 p-4 rounded-lg border border-slate-800/80 flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] font-mono bg-rose-950/80 text-rose-300 px-2 py-0.5 rounded border border-rose-900/50">
                      Z Score: +4.62 σ (High Extent)
                    </span>
                    <h4 className="text-sm font-bold text-white mt-2.5 inline-block border-b border-teal-500/20 pb-0.5">
                      Siti Aminah (East)
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-0.5 font-mono">Store Terminal: NY_STORE_A</p>

                    <div className="mt-3 p-2.5 bg-slate-950 rounded border border-slate-900 text-[10px]">
                      <div className="text-slate-500 uppercase font-mono tracking-wider text-[8px]">Anomalous Value:</div>
                      <div className="text-base font-bold text-sky-355 font-mono mt-0.5">$95,000.00</div>
                      <div className="text-slate-400 mt-1.5 font-sans italic leading-tight">
                        "East region memiliki basis transaksi yang stabil tinggi di kisaran $4,500. Angka $95,000 menandakan adanya kegagalan sistem billing, dimana invoice yang sama terekam dua kali di basis SQL."
                      </div>
                    </div>

                    <div className="mt-3 space-y-1">
                      <label className="block text-[9px] text-slate-400 font-mono uppercase">Action Decision taken:</label>
                      <select 
                        value={rcaDecisions[11]?.decision}
                        onChange={(e) => setRcaDecisions({
                          ...rcaDecisions,
                          11: { ...rcaDecisions[11], decision: e.target.value }
                        })}
                        className="w-full bg-slate-950 border border-slate-800 px-2 py-1 rounded text-[10px] font-mono text-white focus:outline-none focus:border-teal-500"
                      >
                        <option value="INVESTIGATE_SYSTEM">PATCH (Sistem ERP Crash / Investigasi Duplikasi)</option>
                        <option value="APPROVE_AS_VIP">APPROVE (Mega Wholesale B2B Purchase)</option>
                        <option value="VOID_ENTIRELY">VOID (Batalkan transaksi, hapus total)</option>
                      </select>
                    </div>

                    <div className="mt-2.5">
                      <label className="block text-[9px] text-slate-550 font-mono uppercase">Justifikasi Analistik:</label>
                      <textarea
                        value={rcaDecisions[11]?.justification}
                        onChange={(e) => setRcaDecisions({
                          ...rcaDecisions,
                          11: { ...rcaDecisions[11], justification: e.target.value }
                        })}
                        className="w-full h-16 bg-slate-950 border border-slate-800 p-1.5 text-[10px] rounded mt-0.5 text-slate-300 focus:outline-none focus:border-teal-500 font-sans"
                      />
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-850 text-[9px] text-slate-500 italic flex items-center gap-1">
                    <Check className="w-3 h-3 text-teal-400" />
                    Action integrated into portfolio deck
                  </div>
                </div>

                {/* Outlier Case 3: Central Region Rian Hidayat */}
                <div className="bg-slate-900/40 p-4 rounded-lg border border-slate-800/80 flex flex-col justify-between">
                  <div>
                    <span className="text-[9px] font-mono bg-rose-950/80 text-rose-300 px-2 py-0.5 rounded border border-rose-900/50">
                      Z Score: +3.94 σ (Critical Breach)
                    </span>
                    <h4 className="text-sm font-bold text-white mt-2.5 inline-block border-b border-teal-500/20 pb-0.5">
                      Rian Hidayat (Central)
                    </h4>
                    <p className="text-[10px] text-slate-400 mt-0.5 font-mono">Store Terminal: CHI_STORE_A</p>

                    <div className="mt-3 p-2.5 bg-slate-950 rounded border border-slate-900 text-[10px]">
                      <div className="text-slate-500 uppercase font-mono tracking-wider text-[8px]">Anomalous Value:</div>
                      <div className="text-base font-bold text-sky-355 font-mono mt-0.5">$32,000.00</div>
                      <div className="text-slate-400 mt-1.5 font-sans italic leading-tight">
                        "Terletak jauh di atas rata-rata region Central ($1,800). Kemungkinan terjadi penyalahgunaan wewenang staf yang memberikan potongan harga kustom tanpa otorisasi kunci regional (bypass approval)."
                      </div>
                    </div>

                    <div className="mt-3 space-y-1">
                      <label className="block text-[9px] text-slate-400 font-mono uppercase">Action Decision taken:</label>
                      <select 
                        value={rcaDecisions[19]?.decision}
                        onChange={(e) => setRcaDecisions({
                          ...rcaDecisions,
                          19: { ...rcaDecisions[19], decision: e.target.value }
                        })}
                        className="w-full bg-slate-950 border border-slate-800 px-2 py-1 rounded text-[10px] font-mono text-white focus:outline-none focus:border-teal-500"
                      >
                        <option value="AUDIT_AND_FLAG">FLAG & DISCIPLINARY (Ganti Kredensial & Audit Staf)</option>
                        <option value="CORRECT_VALUE">ADJUST (Sesuaikan nilai ke harga normal)</option>
                        <option value="APPROVE_EXCEPTION">ALLOW (Otomatisasi Bypass oleh Direksi)</option>
                      </select>
                    </div>

                    <div className="mt-2.5">
                      <label className="block text-[9px] text-slate-550 font-mono uppercase">Justifikasi Analistik:</label>
                      <textarea
                        value={rcaDecisions[19]?.justification}
                        onChange={(e) => setRcaDecisions({
                          ...rcaDecisions,
                          19: { ...rcaDecisions[19], justification: e.target.value }
                        })}
                        className="w-full h-16 bg-slate-950 border border-slate-800 p-1.5 text-[10px] rounded mt-0.5 text-slate-300 focus:outline-none focus:border-teal-500 font-sans"
                      />
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-850 text-[9px] text-slate-500 italic flex items-center gap-1">
                    <Check className="w-3 h-3 text-teal-400" />
                    Action integrated into portfolio deck
                  </div>
                </div>

              </div>

              {/* Action Executive Report preview container */}
              <div className="bg-slate-900/40 p-4 rounded-lg border border-slate-800 space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 text-[10px] font-mono uppercase border-b border-slate-800 pb-1.5">
                  <TrendingUp className="w-3.5 h-3.5 animate-pulse" />
                  Rekomendasi Implementasi Bisnis Permanen (Preventive Action)
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 leading-normal text-slate-300">
                  <div className="bg-slate-950 p-3 rounded border border-slate-900/80 space-y-1">
                    <strong className="text-white text-xs block font-sans">1. Memasang Input Mask Masukan di POS:</strong>
                    <p className="text-[10px] text-slate-400">
                      Sistem input ERP ritel harus menolak entri angka beruntun yang bernilai 10x lipat lebih tinggi dari rata-rata batas berjalan historis cabang, kecuali telah lolos enkripsi otorisasi supervisor.
                    </p>
                  </div>
                  <div className="bg-slate-950 p-3 rounded border border-slate-900/80 space-y-1">
                    <strong className="text-white text-xs block font-sans">2. Otomatisasi Alerting Menggunakan DBeaver Core Tasks:</strong>
                    <p className="text-[10px] text-slate-400">
                      Memasang scheduler SQL skrip pemicu Z-score pabean untuk dieksekusi harian jam 23.59 malam. Jika ada order dengan |Z| &gt; 3.0, email alert otomatis terkirim langsung ke direktur regional.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          )}

          {/* TAB 4: THE LIVE PRESENTATION CAROUSEL & PPTX EXPORTER */}
          {activeTab === "presentation" && (
            <div className="space-y-4">
              
              {/* Dynamic Presentation Config Form Card */}
              <div className="bg-slate-900/40 p-3.5 rounded-lg border border-slate-800 space-y-3">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-1.5 border-l-2 border-teal-400 pl-2">
                      <Presentation className="text-teal-400 w-4 h-4" />
                      Executive Presentation Exporter
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      Personalisasikan identitas slide presentasi Anda dan unduh langsung file asli .pptx secara dinamis!
                    </p>
                  </div>

                  {/* Primary Download trigger button */}
                  <button
                    onClick={handleExportPPTX}
                    className="px-4 py-2 bg-gradient-to-r from-teal-400 via-emerald-500 to-teal-500 hover:from-teal-350 hover:to-emerald-400 text-slate-950 font-bold rounded text-xs transition-all shadow-md flex items-center gap-1.5 cursor-pointer group"
                  >
                    <Download className="w-4 h-4 text-slate-950 group-hover:scale-110 transition-transform" />
                    Unduh File PPT Presentasi
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2.5 border-t border-slate-850/60">
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono uppercase mb-0.5">Slide Cover Utama Title:</label>
                    <input 
                      type="text" 
                      value={mainTitle}
                      onChange={(e) => setMainTitle(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 px-2 py-1.5 rounded text-[10px] text-white focus:outline-none focus:border-teal-500 font-sans"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 font-mono uppercase mb-0.5">Author / Nama Senior Data Analyst:</label>
                    <div className="relative">
                      <input 
                        type="text" 
                        value={authorName}
                        onChange={(e) => setAuthorName(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-800 pl-7 pr-2 py-1.5 rounded text-[10px] text-white focus:outline-none focus:border-teal-500 font-sans"
                      />
                      <User className="w-3 h-3 text-slate-500 absolute left-2.5 top-2.5" />
                    </div>
                  </div>
                </div>
              </div>

              {/* PowerPoint Live Presentation Player Viewport */}
              <div className="bg-slate-900 rounded-lg border border-slate-800 overflow-hidden flex flex-col">
                
                {/* Visual Slide Header controls */}
                <div className="p-2.5 bg-slate-950 border-b border-slate-850 flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-yellow-500"></span>
                    <span className="w-2.5 h-2.5 rounded-full bg-green-500"></span>
                    <span className="text-[10px] text-slate-400 ml-1.5 font-mono">Cover Preview (Active Slide: {activeSlideIdx + 1} / 6)</span>
                  </div>

                  <div className="flex items-center gap-0.5 bg-slate-900 p-0.5 rounded">
                    {PRESENTATION_SLIDES.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setActiveSlideIdx(i)}
                        className={`w-5 py-0.5 text-[9px] font-mono rounded cursor-pointer ${activeSlideIdx === i ? 'bg-teal-500 text-slate-950 font-bold' : 'text-slate-400 hover:bg-slate-800'}`}
                      >
                        {i + 1}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Simulated Presentation Slide frame (Widescreen 16:9 ratio in CSS) */}
                <div className="bg-slate-950 p-4 flex justify-center items-center">
                  <div className="w-full max-w-2xl aspect-[16/9] relative rounded shadow-xl overflow-hidden border border-slate-800 flex flex-col justify-between">
                    
                    {/* Slide 1: Exclusive cover layouts */}
                    {activeSlideIdx === 0 ? (
                      <div className="absolute inset-0 bg-slate-900 flex flex-col justify-between p-6 text-left border-l-[8px] border-teal-400">
                        <div className="space-y-1">
                          <span className="text-[8px] font-mono text-teal-400 uppercase tracking-widest font-bold">CASE STUDY ANALYTICS</span>
                          <h2 className="text-xl md:text-2xl font-bold text-white tracking-tight leading-tight pt-1">
                            {mainTitle}
                          </h2>
                          <div className="h-0.5 w-12 bg-emerald-500 mt-1"></div>
                        </div>

                        <div className="space-y-1 font-mono text-[9px] text-slate-450 border-t border-slate-800/80 pt-3">
                          <p className="text-white">Senior Lead Analyst: <span className="text-teal-300 font-sans font-bold">{authorName}</span></p>
                          <p>Database Engine: MySQL v8.0 Standard Enterprise</p>
                          <p>Statistical Formula: Population Standard Deviation & Z-Score</p>
                        </div>
                      </div>
                    ) : (
                      // Dynamic pages (Slide 2 to 6)
                      <div className="absolute inset-0 bg-slate-50 flex flex-col justify-between p-6 text-slate-900 border-l-[8px] border-slate-900">
                        <div>
                          <div className="flex justify-between items-center">
                            <span className="text-[8px] font-mono font-bold uppercase text-teal-600 bg-teal-50 px-1.5 py-0.5 rounded border border-teal-100">
                              {PRESENTATION_SLIDES[activeSlideIdx].badge}
                            </span>
                            <span className="text-[8px] font-mono text-slate-400">SLIDE {activeSlideIdx + 1} OF 6</span>
                          </div>
                          
                          <h3 className="text-sm md:text-base font-bold text-slate-900 tracking-tight pt-1">
                            {PRESENTATION_SLIDES[activeSlideIdx].title}
                          </h3>
                          <p className="text-[10px] text-slate-500 italic mt-0.5">
                            {PRESENTATION_SLIDES[activeSlideIdx].subtitle}
                          </p>

                          {/* Bullet points mapping */}
                          <div className="space-y-1.5 mt-3">
                            {PRESENTATION_SLIDES[activeSlideIdx].points.map((pt, pIdx) => (
                              <div key={pIdx} className="flex gap-2 items-start text-[10px] md:text-[11px] text-slate-800 leading-normal font-sans">
                                <span className="text-teal-600 font-bold shrink-0">•</span>
                                <p>{pt}</p>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Interactive dynamic injection results inside the preview slide (discovery) */}
                        {PRESENTATION_SLIDES[activeSlideIdx].visualType === "rca" && (
                          <div className="bg-yellow-50 p-2 rounded border border-yellow-200 mt-1.5">
                            <div className="text-[8px] font-extrabold text-amber-800 font-sans uppercase">Workspace Decisions Integrated:</div>
                            <div className="grid grid-cols-3 gap-1.5 text-[8px] font-mono text-amber-900 mt-0.5">
                              <div>West VP: <strong className="text-amber-800">{rcaDecisions[5]?.decision}</strong></div>
                              <div>East VP: <strong className="text-amber-800">{rcaDecisions[11]?.decision}</strong></div>
                              <div>Central VP: <strong className="text-amber-800">{rcaDecisions[19]?.decision}</strong></div>
                            </div>
                          </div>
                        )}

                        <div className="border-t border-slate-200 text-[9px] text-slate-400 font-mono flex justify-between items-center pt-1.5">
                          <span>Portfolio Project Case: Recovery Anomaly</span>
                          <span>MySQL-Dbeaver</span>
                        </div>
                      </div>
                    )}

                  </div>
                </div>

                {/* Bottom interactive guide panel */}
                <div className="p-3 bg-slate-950/70 border-t border-slate-850 text-[10px] text-slate-450 flex flex-col md:flex-row justify-between gap-2">
                  <span className="flex items-center gap-1">
                    <Sparkles className="w-3 h-3 text-teal-400" />
                    Presentasi dirancang menggunakan proporsi layout eksekutif minimalis Slate-White modern.
                  </span>
                  
                  <div className="flex gap-1.5">
                    <button 
                      onClick={() => setActiveSlideIdx(prev => prev > 0 ? prev - 1 : 0)}
                      disabled={activeSlideIdx === 0}
                      className="px-2.5 py-0.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-850 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer text-[10px]"
                    >
                      Prev
                    </button>
                    <button 
                      onClick={() => setActiveSlideIdx(prev => prev < 5 ? prev + 1 : 5)}
                      disabled={activeSlideIdx === 5}
                      className="px-2.5 py-0.5 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded border border-slate-850 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer text-[10px]"
                    >
                      Next
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

        </div>
      </main>

      {/* Corporate footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-4 px-6 text-center text-[10px] text-slate-500 font-mono">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-2">
          <p>© 2026 Executive Sales Recovery Project Portfolio - Haris Aritonang.</p>
          <div className="flex gap-3">
            <span>MySQL 8.0 standard</span>
            <span>DBeaver IDE mapping</span>
            <span>Z-Score Outlier Trigger</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
